<?php
/**
 * Variable product add to cart
 *
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.4.1
 *
 * Modified to use radio buttons instead of dropdowns
 * @author 8manos
 */

defined( 'ABSPATH' ) || exit;

global $product;
global $woocommerce;

$attribute_keys = array_keys( $attributes );

do_action( 'woocommerce_before_add_to_cart_form' );
add_action('wp_footer', function(){
    ?>
    <script>
        
        jQuery(document).ready(function($) {
          $('.anony-variation-label').on('click', function(){
              var target = $(this).attr('for');
              $('.anony-variation-value').removeClass('anony-variation-visible');
              $('#' + target + '_values').addClass('anony-variation-visible');
              console.log(target);
          });
        });
    </script>
    <?php
});
?>

<style>
    
    .anony-variations{
        display: flex;
    }
    .anony-variation{
        margin: 5px;
        display: inline-flex;
        justify-content:center;
        align-items:center;
        background-color:#A41E01;
        color:#fff;
        border-radius:8px;
    }
    
    .anony-variation-value{
        background-color:#fff;
        color: #000;
        position:fixed;
        bottom:0;
        right: 0;
        padding:10px;
        border-radius:8px;
        z-index: 20;
        width: 100%;
        display:none;
        -webkit-box-shadow: 0px 0px 5px 0px rgba(194,194,194,1);
        -moz-box-shadow: 0px 0px 5px 0px rgba(194,194,194,1);
        box-shadow: 0px 0px 5px 0px rgba(194,194,194,1);

    }
    .anony-variation-value.anony-variation-visible{
        display:block;
    }
    .anony-variation-label{
        display: inline-flex;
        justify-content:center;
        align-items:center;
        height:80px;
        width:100px;
        cursor:pointer;
        
    }
</style>
<form class="variations_form cart" action="<?php echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); ?>" method="post" enctype='multipart/form-data' data-product_id="<?php echo absint( $product->get_id() ); ?>" data-product_variations="<?php echo htmlspecialchars( wp_json_encode( $available_variations ) ) ?>">
	<?php do_action( 'woocommerce_before_variations_form' ); ?>

	<?php if ( empty( $available_variations ) && false !== $available_variations ) : ?>
		<p class="stock out-of-stock"><?php esc_html_e( 'This product is currently out of stock and unavailable.', 'woocommerce' ); ?></p>
	<?php else : ?>
		<div class="variations anony-variations" cellspacing="0">
				<?php foreach ( $attributes as $name => $options ) : ?>
                    <?php $sanitized_name = sanitize_title( $name ); ?>
                    <div class="variation anony-variation attribute-<?php echo esc_attr( $sanitized_name ); ?>">
                        <div><label class="label anony-variation-label" for="<?php echo esc_attr( $sanitized_name ); ?>"><?php echo wc_attribute_label( $name ); ?></label></div>
                        <?php
                        if ( isset( $_REQUEST[ 'attribute_' . $sanitized_name ] ) ) {
                            $checked_value = $_REQUEST[ 'attribute_' . $sanitized_name ];
                        } elseif ( isset( $selected_attributes[ $sanitized_name ] ) ) {
                            $checked_value = $selected_attributes[ $sanitized_name ];
                        } else {
                            $checked_value = '';
                        }
                        ?>
                        <div id="<?php echo esc_attr( $sanitized_name ); ?>_values" class="value anony-variation-value">
                            <?php
                            if ( ! empty( $options ) ) {
                                if ( taxonomy_exists( $name ) ) {
                                    // Get terms if this is a taxonomy - ordered. We need the names too.
                                    $terms = wc_get_product_terms( $product->get_id(), $name, array( 'fields' => 'all' ) );
                
                                    foreach ( $terms as $term ) {
                                        if ( ! in_array( $term->slug, $options ) ) {
                                            continue;
                                        }
                                        ?>
                                        <div class="variation-option">
                                            <?php print_attribute_radio( $checked_value, $term->slug, $term->name, $sanitized_name ); ?>
                                        </div>
                                        <?php
                                    }
                                } else {
                                    foreach ( $options as $option ) {
                                        ?>
                                        <div class="variation-option">
                                            <?php print_attribute_radio( $checked_value, $option, $option, $sanitized_name ); ?>
                                        </div>
                                        <?php
                                    }
                                }
                            }
                
                            if ( end( $attribute_keys ) === $name ) {
                                echo wp_kses_post( apply_filters( 'woocommerce_reset_variations_link', '<div class="reset_variations"><a href="#">' . esc_html__( 'Clear', 'woocommerce' ) . '</a></div>' ) );
                            }
                            ?>
                        </div>
                    </div>
                <?php endforeach; ?>
		</div>

		<?php
			if ( version_compare($woocommerce->version, '3.4.0') < 0 ) {
				do_action( 'woocommerce_before_add_to_cart_button' );
			}
		?>

		<div class="single_variation_wrap">
			<?php
				do_action( 'woocommerce_before_single_variation' );
				do_action( 'woocommerce_single_variation' );
				do_action( 'woocommerce_after_single_variation' );
			?>
		</div>

		<?php
			if ( version_compare($woocommerce->version, '3.4.0') < 0 ) {
				do_action( 'woocommerce_after_add_to_cart_button' );
			}
		?>
	<?php endif; ?>

	<?php do_action( 'woocommerce_after_variations_form' ); ?>
</form>

<?php do_action( 'woocommerce_after_add_to_cart_form' ); ?>
